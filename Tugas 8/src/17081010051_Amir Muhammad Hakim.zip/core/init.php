<?php

session_start();

require_once("functions/db.php");
require_once("functions/user.php");
require_once("functions/inv.php");