    <footer>
        &copy; @mramirid <?php echo date("o"); ?>
    </footer>
</body>
</html>